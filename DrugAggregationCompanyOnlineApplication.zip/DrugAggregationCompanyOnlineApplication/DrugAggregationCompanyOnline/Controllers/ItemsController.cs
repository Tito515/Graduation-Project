﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DrugAggregationCompanyOnline.Models;
using DrugAggregationCompanyOnline.Repositories;
using DrugAggregationCompanyOnline.ViewModels;


namespace DrugAggregationCompanyOnline.Controllers
{
    public class ItemsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();
        //private readonly IAddReposetory<ItemViewModel> _repo;
        //private readonly IDeleteRepository<Item> _deleteItemRepo;
        private readonly ItemRepository _repo;


        public ItemsController()
        {
            _repo = new ItemRepository();
           
        }

        // GET: Items
        public ActionResult Index()
        {
            return View(db.Items.ToList());
        }

        // GET: Items/Details/5
        public ActionResult Details(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Item item = db.Items.Find(id);
            if (item == null)
            {
                return HttpNotFound();
            }
            return View(item);
        }

        // GET: Items/Create
        public ActionResult AddItem()
        {
            ViewBag.CategoryName = new SelectList(db.Category.ToList(), "ID", "Name");
            return View();
        }

        // POST: Items/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddItem(ItemViewModel _ivm)
        {
            string serverPath = Server.MapPath("~/Image/Item_Photo");
            _repo.Add(_ivm, serverPath);
            return RedirectToAction(nameof(Index));
        }

        // GET: Items/Edit/5
        public ActionResult Edit(Guid? id)
        {
            ViewBag.CategoryName = new SelectList(db.Category.ToList(), "ID", "Name");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Item item = db.Items.Find(id);
            if (item == null)
            {
                return HttpNotFound();
            }
            return View(item);
        }

        // POST: Items/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Guid id ,ItemViewModel _ivm)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    string serverPath = Server.MapPath("~/Image/Item_Photo");

                    _repo.Edit(id, _ivm, serverPath);
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                   
                }
               
            }

            ViewBag.CategoryName = new SelectList(db.Category.ToList(), "ID", "Name");
            return View();
        }

        // GET: Items/Delete/5
        public ActionResult Delete(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Item item = db.Items.Find(id);
            if (item == null)
            {
                return HttpNotFound();
            }
            return View(item);
        }

        // POST: Items/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(Guid id)
        {
           
            _repo.Delete(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
