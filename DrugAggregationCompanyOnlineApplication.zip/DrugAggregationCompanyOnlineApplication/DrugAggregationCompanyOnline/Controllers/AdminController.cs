﻿using DrugAggregationCompanyOnline.Infrastructure;
using DrugAggregationCompanyOnline.Models;
using DrugAggregationCompanyOnline.Repositories;
using DrugAggregationCompanyOnline.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace DrugAggregationCompanyOnline.Controllers
{
    [CustomAuthenticationFilter]
    [CustomAuthorize("Super Admin")]
    public class AdminController : Controller
    {
       
        // GET: Admin
       
        public ActionResult Dashboard()
        {
            return View();
        }


        








    }
}