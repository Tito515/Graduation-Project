﻿using DrugAggregationCompanyOnline.Infrastructure;
using DrugAggregationCompanyOnline.Models;
using DrugAggregationCompanyOnline.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DrugAggregationCompanyOnline.Controllers
{
    [CustomAuthenticationFilter]
    [CustomAuthorize("Customer")]
    public class ShoppingController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();
        private List<shoppingCart> ShoppingCartList;
        public ShoppingController()
        {
            ShoppingCartList = new List<shoppingCart>();
        }

        // GET: Shopping
        public ActionResult Index(string searchText)
        {

            if (!string.IsNullOrEmpty(searchText))
            {
                var item = db.Items.Where(i => i.Name.Contains(searchText)).ToList();
                return View(item);
            }
            return View(db.Items.ToList());
        }

        [HttpPost]
        public JsonResult Index(string itemId, int quantity)
        {

            shoppingCart _shoppingCart = new shoppingCart();
            var item = db.Items.SingleOrDefault(model => model.ID.ToString() == itemId);
            if (Session["CartCount"] != null)
            {
                ShoppingCartList = Session["CartItems"] as List<shoppingCart>;
            }
           
            if (ShoppingCartList.Any(model => model.itemID == itemId))
            {
                _shoppingCart = ShoppingCartList.SingleOrDefault(model => model.itemID == itemId);
                _shoppingCart.Quantity = quantity;
                _shoppingCart.Total = _shoppingCart.Quantity * _shoppingCart.unitPrice;
            }
            else
            {
                _shoppingCart.itemID = itemId;
                _shoppingCart.itemName = item.Name;
                _shoppingCart.imagePath = item.Photo;
                _shoppingCart.Quantity = quantity;
                _shoppingCart.unitPrice = item.Price;
                _shoppingCart.Total = _shoppingCart.Quantity * _shoppingCart.unitPrice;
                ShoppingCartList.Add(_shoppingCart);

            }
            
            Session["CartCount"] = ShoppingCartList.Count();
            Session["CartItems"] = ShoppingCartList;


            return Json(new
            {
                Success = true,
                Counter = ShoppingCartList.Count
            }, JsonRequestBehavior.AllowGet);

        }
        public ActionResult ShoppingCart()
        {

            ShoppingCartList = Session["CartItems"] as List<shoppingCart>;
            return View(ShoppingCartList);
        }

        public ActionResult Payment()
        {


            return View();
        }
        public ActionResult RemoveItem(string itemId)
        {
            if (Session["CartCount"] != null)
            {
                ShoppingCartList = Session["CartItems"] as List<shoppingCart>;
            }

            var item = ShoppingCartList.Find(x => x.itemID == itemId);
            ShoppingCartList.Remove(item);
            if (ShoppingCartList.Count() == 0)
            {
                Session["CartCount"] = null;
                Session["CartItems"] = null;
                return RedirectToAction("Index");

            }
            else
            {
                Session["CartCount"] = ShoppingCartList.Count();
                Session["CartItems"] = ShoppingCartList;
                return RedirectToAction(nameof(ShoppingCart));
            }

        }
        public ActionResult ItemDetails(string id)
        {
            var item = db.Items.FirstOrDefault(i => i.ID.ToString() == id);
            return View(item);
        }
        [HttpPost]
        public ActionResult AddOrder(ImageViewModel image)
        {
            var ListOrderDetails = new List<OrderDetail>();
            string ServerPath = Server.MapPath("~/Image/PaymentPhoto");
            string folderpath = "/Image/PaymentPhoto/";

            if (Session["CartCount"] != null)
            {
                ShoppingCartList = Session["CartItems"] as List<shoppingCart>;
            }
            var order = new Order
            {
                ID = Guid.NewGuid(),
                Date = DateTime.Now,
                DeliveryDate = DateTime.Now.AddDays(10),
                PaymentPhoto = image.UploadImage(image, ServerPath, folderpath),
                OrderDetails = new List<OrderDetail>(ListOrderDetails),
                OrderState = "false",
                UserID = Guid.Parse(Session["UserId"].ToString())



            };
            db.Orders.Add(order);

            foreach (var item in ShoppingCartList)
            {
                ListOrderDetails.Add(new OrderDetail
                {

                    ID = Guid.NewGuid(),
                    Item = db.Items.Find(Guid.Parse(item.itemID)),//to get the item data,
                    Price = item.unitPrice,
                    Quantity = item.Quantity,
                    Order = db.Orders.Find(order.ID)
                });

            }
            db.OrderDetails.AddRange(ListOrderDetails);
            db.SaveChanges();


            Session["CartCount"] = null;
            Session["CartItems"] = null;


            return RedirectToAction("Index");
        }

        public ActionResult TrackOrders()
        {
            var _userName= Session["UserName"];
            var orders = db.Orders.Where(o => o.User.Name == (string)_userName).ToList();
            if (orders == null)
            {
                return View("There is no Orders");
            }
            return View(orders);
        }
        public ActionResult CanselOrder()
        {
            Session["CartCount"] = null;
            Session["CartItems"] = null;

            return RedirectToAction("Index");
        }
    }
}
