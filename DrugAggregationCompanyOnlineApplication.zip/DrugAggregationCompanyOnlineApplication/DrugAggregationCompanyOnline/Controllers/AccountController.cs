﻿using DrugAggregationCompanyOnline.Models;
using DrugAggregationCompanyOnline.Repositories;
using DrugAggregationCompanyOnline.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;


namespace DrugAggregationCompanyOnline.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserRepository _repository;
        public AccountController()
        {
            _context = new ApplicationDbContext();
            _repository = new UserRepository();
        }


        // GET: Account

        public ActionResult GetAllUsers()
        {
            return View(_repository.GetAllUsers());
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(LogInViewModel _uvm)
        {
            if (ModelState.IsValid)
            {
                User user = _context.User
                                      .Where(u => u.UserName == _uvm.Username
                                      && u.Password == _uvm.Password)
                                      .FirstOrDefault();

                if (user != null)
                {
                    Session["UserName"] = user.UserName;
                    Session["UserId"] = user.ID;
                    Session["Role"] = user.Role.Name;
                    if (user.Role.Name== "Super Admin")
                    {
                        return RedirectToAction("Dashboard", "Admin");
                    }
                    return RedirectToAction("Index", "Home");
                }
               


            }
            ModelState.AddModelError("", "Invalid username or password");
            return RedirectToAction("Login", "Account");

        }

        public ActionResult SignUp()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SignUp(UserViewModel _user)
        {
            string ServerPath = Server.MapPath("~/Image/Licenses");
            _repository.Add(_user , ServerPath);
            return RedirectToAction("Login");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            Session["UserName"] = string.Empty;
            Session["UserId"] = string.Empty;
            return RedirectToAction("Login", "Account");
        }



       
    }
}