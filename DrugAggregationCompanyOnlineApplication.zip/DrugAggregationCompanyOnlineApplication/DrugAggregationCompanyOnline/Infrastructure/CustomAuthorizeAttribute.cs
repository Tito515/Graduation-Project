﻿using DrugAggregationCompanyOnline.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace DrugAggregationCompanyOnline.Infrastructure
{
    public class CustomAuthorizeAttribute : AuthorizeAttribute
    {
        private readonly string[] allowedroles;
        public CustomAuthorizeAttribute(params string[] roles)
        {
            allowedroles = roles;
        }

        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            bool authorize = false;
            var userId = httpContext.Session["UserId"].ToString();
            if (!string.IsNullOrEmpty(userId))
                using (var context = new ApplicationDbContext())
                {
                    var userRole = (from u in context.User
                                    join r in context.Roles on u.RoleID equals r.ID
                                    where u.ID.ToString() == userId
                                    select new
                                    {
                                        r.Name
                                    }).FirstOrDefault();
                    foreach (var role in allowedroles)
                    {
                        if (role == userRole.Name) return true;
                    }
                }
            return authorize;
        }
        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            filterContext.Result = new RedirectToRouteResult(
               new RouteValueDictionary
               {
                    { "controller", "Home" },
                    { "action", "UnAuthorized" }
               });
        }



        /*
         We have inherited base class “AuthorizeAttribute” into this class.
        We will override two important methods “AuthorizeCore” and “HandleUnauthorizedRequest”.
 
        The first method will check the associated roles of an action in a controller with the assigned role of the user.
        If there is no matching role found, this method will return value “false” and authorization will be failed.
        If authorization failed, second overridden method “HandleUnauthorizedRequest”
        will be executed and the page will be redirected to
        a specific “UnAuthorized” action (page) in “Home” controller.
         */
    }
}