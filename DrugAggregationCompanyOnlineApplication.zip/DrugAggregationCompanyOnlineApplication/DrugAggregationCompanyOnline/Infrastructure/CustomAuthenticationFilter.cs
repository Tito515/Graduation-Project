﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Filters;
using System.Web.Routing;

namespace DrugAggregationCompanyOnline.Infrastructure
{
    public class CustomAuthenticationFilter : ActionFilterAttribute, IActionFilter
    {
        public void OnAuthentication(AuthorizationContext filterContext)
        {
            if (string.IsNullOrEmpty(Convert.ToString(
                filterContext.
                HttpContext.
                Session["UserName"])))
            {
                filterContext.Result = new HttpUnauthorizedResult();
            }
        }

        public void OnAuthentecationCallenge(AuthenticationChallengeContext filterContext)
        {
            if (filterContext.Result == null || filterContext.Result is HttpUnauthorizedResult)
            {
                //Redirecting the user to the Login View of Account Controller  
                filterContext.Result = new RedirectToRouteResult
                    (
                   new RouteValueDictionary
                   {
                       {"controller","Acccount" },
                       {"action","Login" }
                   }
                    );
            }

        }
        /*
        We have implemented “ActionFilterAttribute” class and “IAuthenticationFilter” interface in the above class.
       Please note that there are two important methods implemented - “OnAuthentication” and “OnAuthenticationChallenge”.
       Inside OnAuthentication, we have checked the session value “UserName” to see if it is empty or not. 
       If the value is empty, it will throw the result as “HttpUnauthorizedResult” and then, the second method OnAuthenticationChallenge will be executed.
       This method will redirect the request to a specific action and controller.
       In this example, we will redirect to “Login” action in “Account” controller.
        */
    }
}