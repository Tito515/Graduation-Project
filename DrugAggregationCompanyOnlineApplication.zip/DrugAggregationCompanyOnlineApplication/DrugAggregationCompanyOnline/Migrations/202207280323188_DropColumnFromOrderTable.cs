namespace DrugAggregationCompanyOnline.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class DropColumnFromOrderTable : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.Orders", "OrderState");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Orders", "OrderState", c => c.Boolean(nullable: false));
        }
    }
}
