namespace DrugAggregationCompanyOnline.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddItemAndCompanyCategoryAndTypeTable : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Categories",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        Name = c.String(nullable: false, maxLength: 50),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Items",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        Name = c.String(nullable: false, maxLength: 100),
                        Price = c.Double(nullable: false),
                        Photo = c.String(nullable: false),
                        Category_ID = c.Guid(),
                        Company_ID = c.Guid(),
                        Type_ID = c.Guid(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Categories", t => t.Category_ID)
                .ForeignKey("dbo.Companies", t => t.Company_ID)
                .ForeignKey("dbo.Types", t => t.Type_ID)
                .Index(t => t.Category_ID)
                .Index(t => t.Company_ID)
                .Index(t => t.Type_ID);
            
            CreateTable(
                "dbo.Companies",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        Name = c.String(nullable: false, maxLength: 50),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Types",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        Name = c.String(nullable: false, maxLength: 50),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Items", "Type_ID", "dbo.Types");
            DropForeignKey("dbo.Items", "Company_ID", "dbo.Companies");
            DropForeignKey("dbo.Items", "Category_ID", "dbo.Categories");
            DropIndex("dbo.Items", new[] { "Type_ID" });
            DropIndex("dbo.Items", new[] { "Company_ID" });
            DropIndex("dbo.Items", new[] { "Category_ID" });
            DropTable("dbo.Types");
            DropTable("dbo.Companies");
            DropTable("dbo.Items");
            DropTable("dbo.Categories");
        }
    }
}
