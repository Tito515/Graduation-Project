namespace DrugAggregationCompanyOnline.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreateItemTable : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Items",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        Name = c.String(nullable: false, maxLength: 50),
                        Price = c.Double(nullable: false),
                        Photo = c.String(nullable: false),
                        Company = c.String(nullable: false),
                        Category_ID = c.Guid(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Categories", t => t.Category_ID, cascadeDelete: true)
                .Index(t => t.Category_ID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Items", "Category_ID", "dbo.Categories");
            DropIndex("dbo.Items", new[] { "Category_ID" });
            DropTable("dbo.Items");
        }
    }
}
