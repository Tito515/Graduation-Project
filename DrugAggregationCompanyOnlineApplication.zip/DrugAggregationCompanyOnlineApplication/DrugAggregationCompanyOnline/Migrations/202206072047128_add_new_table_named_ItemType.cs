namespace DrugAggregationCompanyOnline.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class add_new_table_named_ItemType : DbMigration
    {
        public override void Up()
        {
            RenameTable(name: "dbo.Types", newName: "ItemTypes");
            RenameColumn(table: "dbo.Items", name: "Type_ID", newName: "ItemType_ID");
            RenameIndex(table: "dbo.Items", name: "IX_Type_ID", newName: "IX_ItemType_ID");
        }
        
        public override void Down()
        {
            RenameIndex(table: "dbo.Items", name: "IX_ItemType_ID", newName: "IX_Type_ID");
            RenameColumn(table: "dbo.Items", name: "ItemType_ID", newName: "Type_ID");
            RenameTable(name: "dbo.ItemTypes", newName: "Types");
        }
    }
}
