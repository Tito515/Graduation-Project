namespace DrugAggregationCompanyOnline.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class EditUserTable : DbMigration
    {
        public override void Up()
        {
            RenameColumn(table: "dbo.Users", name: "Role_ID", newName: "RoleID");
            RenameIndex(table: "dbo.Users", name: "IX_Role_ID", newName: "IX_RoleID");
        }
        
        public override void Down()
        {
            RenameIndex(table: "dbo.Users", name: "IX_RoleID", newName: "IX_Role_ID");
            RenameColumn(table: "dbo.Users", name: "RoleID", newName: "Role_ID");
        }
    }
}
