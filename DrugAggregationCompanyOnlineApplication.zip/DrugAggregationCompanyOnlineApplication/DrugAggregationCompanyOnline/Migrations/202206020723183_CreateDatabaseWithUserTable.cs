﻿namespace DrugAggregationCompanyOnline.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreateDatabaseWithUserTable : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Users",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        Name = c.String(nullable: false, maxLength: 40),
                        UserName = c.String(nullable: false, maxLength: 40),
                        Email = c.String(),
                        Password = c.String(nullable: false, maxLength: 50),
                        Address = c.String(nullable: false),
                        PhoneNo = c.String(nullable: false),
                        Licenses = c.Byte(nullable: false),
                        Role = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Users");
        }
    }
}
