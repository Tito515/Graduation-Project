namespace DrugAggregationCompanyOnline.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class RemoveIdentityAttrebuetToIdColumnInUserModel : DbMigration
    {
        public override void Up()
        {
            DropPrimaryKey("dbo.Users");
            AlterColumn("dbo.Users", "ID", c => c.Guid(nullable: false));
            AddPrimaryKey("dbo.Users", "ID");
        }
        
        public override void Down()
        {
            DropPrimaryKey("dbo.Users");
            AlterColumn("dbo.Users", "ID", c => c.Guid(nullable: false, identity: true));
            AddPrimaryKey("dbo.Users", "ID");
        }
    }
}
