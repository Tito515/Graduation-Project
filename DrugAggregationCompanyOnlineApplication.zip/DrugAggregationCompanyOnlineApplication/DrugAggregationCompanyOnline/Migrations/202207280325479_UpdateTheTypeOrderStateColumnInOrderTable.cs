namespace DrugAggregationCompanyOnline.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateTheTypeOrderStateColumnInOrderTable : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Orders", "OrderState", c => c.String(nullable: false, maxLength: 5));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Orders", "OrderState");
        }
    }
}
