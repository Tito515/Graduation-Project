namespace DrugAggregationCompanyOnline.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class EditTheNameOfTheCategoryPropertyInCategorTable : DbMigration
    {
        public override void Up()
        {
            RenameColumn(table: "dbo.Items", name: "Category_ID", newName: "_Category_ID");
            RenameIndex(table: "dbo.Items", name: "IX_Category_ID", newName: "IX__Category_ID");
        }
        
        public override void Down()
        {
            RenameIndex(table: "dbo.Items", name: "IX__Category_ID", newName: "IX_Category_ID");
            RenameColumn(table: "dbo.Items", name: "_Category_ID", newName: "Category_ID");
        }
    }
}
