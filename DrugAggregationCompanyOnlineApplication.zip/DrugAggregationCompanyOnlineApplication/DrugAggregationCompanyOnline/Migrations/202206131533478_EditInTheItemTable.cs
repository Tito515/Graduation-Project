namespace DrugAggregationCompanyOnline.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class EditInTheItemTable : DbMigration
    {
        public override void Up()
        {
            RenameColumn(table: "dbo.Items", name: "_Category_ID", newName: "CategoryID");
            RenameIndex(table: "dbo.Items", name: "IX__Category_ID", newName: "IX_CategoryID");
        }
        
        public override void Down()
        {
            RenameIndex(table: "dbo.Items", name: "IX_CategoryID", newName: "IX__Category_ID");
            RenameColumn(table: "dbo.Items", name: "CategoryID", newName: "_Category_ID");
        }
    }
}
