namespace DrugAggregationCompanyOnline.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddRoleTableToTheDatabase : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Roles",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        Name = c.Guid(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
            AddColumn("dbo.Users", "Role_ID", c => c.Guid());
            CreateIndex("dbo.Users", "Role_ID");
            AddForeignKey("dbo.Users", "Role_ID", "dbo.Roles", "ID");
            DropColumn("dbo.Users", "Role");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Users", "Role", c => c.String());
            DropForeignKey("dbo.Users", "Role_ID", "dbo.Roles");
            DropIndex("dbo.Users", new[] { "Role_ID" });
            DropColumn("dbo.Users", "Role_ID");
            DropTable("dbo.Roles");
        }
    }
}
