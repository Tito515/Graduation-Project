namespace DrugAggregationCompanyOnline.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class DeleteItemTalbe : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Items", "Category_ID", "dbo.Categories");
            DropForeignKey("dbo.Items", "Company_ID", "dbo.Companies");
            DropForeignKey("dbo.Items", "ItemType_ID", "dbo.ItemTypes");
            DropIndex("dbo.Items", new[] { "Category_ID" });
            DropIndex("dbo.Items", new[] { "Company_ID" });
            DropIndex("dbo.Items", new[] { "ItemType_ID" });
            DropTable("dbo.Items");
            DropTable("dbo.Companies");
            DropTable("dbo.ItemTypes");
        }
        
        public override void Down()
        {
            CreateTable(
                "dbo.ItemTypes",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        Name = c.String(nullable: false, maxLength: 50),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Companies",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        Name = c.String(nullable: false, maxLength: 50),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Items",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        Name = c.String(nullable: false, maxLength: 100),
                        Price = c.Double(nullable: false),
                        Photo = c.String(nullable: false),
                        Category_ID = c.Guid(),
                        Company_ID = c.Guid(),
                        ItemType_ID = c.Guid(),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateIndex("dbo.Items", "ItemType_ID");
            CreateIndex("dbo.Items", "Company_ID");
            CreateIndex("dbo.Items", "Category_ID");
            AddForeignKey("dbo.Items", "ItemType_ID", "dbo.ItemTypes", "ID");
            AddForeignKey("dbo.Items", "Company_ID", "dbo.Companies", "ID");
            AddForeignKey("dbo.Items", "Category_ID", "dbo.Categories", "ID");
        }
    }
}
