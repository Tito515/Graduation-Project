namespace DrugAggregationCompanyOnline.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class updateDataInOrderTableandOrderDetails : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Orders", "User_ID", "dbo.Users");
            DropIndex("dbo.Orders", new[] { "User_ID" });
            RenameColumn(table: "dbo.Orders", name: "User_ID", newName: "UserID");
            AddColumn("dbo.OrderDetails", "Price", c => c.Decimal(nullable: false, precision: 18, scale: 2));
            AlterColumn("dbo.Items", "Price", c => c.Decimal(nullable: false, precision: 18, scale: 2));
            AlterColumn("dbo.Orders", "UserID", c => c.Guid(nullable: false));
            CreateIndex("dbo.Orders", "UserID");
            AddForeignKey("dbo.Orders", "UserID", "dbo.Users", "ID", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Orders", "UserID", "dbo.Users");
            DropIndex("dbo.Orders", new[] { "UserID" });
            AlterColumn("dbo.Orders", "UserID", c => c.Guid());
            AlterColumn("dbo.Items", "Price", c => c.Double(nullable: false));
            DropColumn("dbo.OrderDetails", "Price");
            RenameColumn(table: "dbo.Orders", name: "UserID", newName: "User_ID");
            CreateIndex("dbo.Orders", "User_ID");
            AddForeignKey("dbo.Orders", "User_ID", "dbo.Users", "ID");
        }
    }
}
