namespace DrugAggregationCompanyOnline.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class EditOnRoleTable : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Roles", "Name", c => c.String(nullable: false, maxLength: 30));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Roles", "Name", c => c.Guid(nullable: false));
        }
    }
}
