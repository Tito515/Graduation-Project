﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace DrugAggregationCompanyOnline.ViewModels
{
    public class ImageViewModel
    {
        public string ImgePath { get; set; }
        public HttpPostedFileBase ImageFile { get; set; }
        public string UploadImage(ImageViewModel imge, string serverPath , string folderPath)
        {
            string fileName = Path.GetFileNameWithoutExtension(imge.ImageFile.FileName);
            string extension = Path.GetExtension(imge.ImageFile.FileName);
            fileName = fileName + Guid.NewGuid().ToString() + "_" + extension;
            imge.ImgePath = folderPath + fileName;
            fileName = Path.Combine(serverPath, fileName);
            imge.ImageFile.SaveAs(fileName);

            return imge.ImgePath;
        }
    }
}