﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace DrugAggregationCompanyOnline.ViewModels
{
    public class ItemViewModel:ImageViewModel
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string Photo { get; set; }
        public string Company { get; set; }
        public Guid CategoryID { get; set; }
        //public string UploadImage(ItemViewModel imge, string serverPath)
        //{
        //    string fileName = Path.GetFileNameWithoutExtension(imge.ImageFile.FileName);
        //    string extension = Path.GetExtension(imge.ImageFile.FileName);
        //    fileName = fileName + Guid.NewGuid().ToString() + "_" + extension;
        //    imge.ImgePath = "/Image/Item_Photo/" + fileName;
        //    fileName = Path.Combine(serverPath, fileName);
        //    imge.ImageFile.SaveAs(fileName);

        //    return imge.ImgePath;
        //}
    }
}