﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace DrugAggregationCompanyOnline.ViewModels
{
    public class UploadImageVM:ImageViewModel
    {

        public string UploadImage(UploadImageVM imge, string serverPath)
        {
            string fileName = Path.GetFileNameWithoutExtension(imge.ImageFile.FileName);
            string extension = Path.GetExtension(imge.ImageFile.FileName);
            fileName = fileName + Guid.NewGuid().ToString() + "_" + extension;
            imge.ImgePath = "/Image/Licenses/" + fileName;
            string FullPath = Path.Combine(serverPath, fileName);
            imge.ImageFile.SaveAs(FullPath);

            return imge.ImgePath;
        }
    }
}