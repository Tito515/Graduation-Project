﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Web;
using DrugAggregationCompanyOnline.Models;


namespace DrugAggregationCompanyOnline.ViewModels
{
    public class UserViewModel : ImageViewModel
    {
        public UserViewModel():base()
        {

        }
        public Guid ID { get; set; } = Guid.NewGuid();
        [Required]
        public string Name { get; set; }
        [Required]
        public string UserName { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        public string Address { get; set; }
        [Required]
        public string PhoneNo { get; set; }
        [Required]
        public string Licenses { get; set; } 
        public Guid _Role { get; set; }

       

    }
}