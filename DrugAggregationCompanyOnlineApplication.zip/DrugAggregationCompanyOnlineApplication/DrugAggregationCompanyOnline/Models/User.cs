﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DrugAggregationCompanyOnline.Models
{
    public class User
    {

        [Key]
        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]//Auto Generation to the ID
        public Guid ID { get; set; }
        
        [Required(ErrorMessage = "Name is required"), MaxLength(40)]
        public string Name { get; set; }
        
        [Required(ErrorMessage = "Username is required"), MaxLength(40)]
        public string UserName { get; set; }
        
        [EmailAddress(ErrorMessage = "Enter your Email")]
        public string Email { get; set; }
        
        [Required(ErrorMessage = "Password is required")]
        [StringLength(50, ErrorMessage = "Must be between 5 and 20 characters", MinimumLength = 8)]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        
        [Required]
        public string Address { get; set; }
        
        [Required]
        public string PhoneNo { get; set; }  
        
        public string Licenses { get; set; }

        public Guid? RoleID { get; set; }
        public virtual Role Role { get; set; }

        public ICollection<Order> Orders { get; set; }


    }
}