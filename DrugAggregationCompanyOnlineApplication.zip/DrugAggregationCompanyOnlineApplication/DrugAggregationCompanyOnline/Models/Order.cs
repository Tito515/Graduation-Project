﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DrugAggregationCompanyOnline.Models
{
    public class Order
    {
        [Key]
        public Guid ID { get; set; }
        [Required]
        public DateTime Date { get; set; }
        [Required]
        public DateTime DeliveryDate { get; set; } 
        [Required]
        public string PaymentPhoto { get; set; }
        //public bool OrderState { get; set; }
        [Required]
        [StringLength(maximumLength:5,MinimumLength =1)]
        public string OrderState { get; set; }
        public Guid UserID { get; set; }
        public virtual User User { get; set; }
        public ICollection<OrderDetail> OrderDetails { get; set; }

    }
}