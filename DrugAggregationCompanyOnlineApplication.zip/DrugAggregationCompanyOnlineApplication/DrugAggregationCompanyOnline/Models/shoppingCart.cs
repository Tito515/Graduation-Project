﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DrugAggregationCompanyOnline.Models
{
    public class shoppingCart
    {
        public string itemID { get; set; }
        public string itemName { get; set; }
        public int Quantity { get; set; }
        public decimal Total { get; set; }
        public decimal unitPrice { get; set; }
        public string imagePath { get; set; }
    }
}