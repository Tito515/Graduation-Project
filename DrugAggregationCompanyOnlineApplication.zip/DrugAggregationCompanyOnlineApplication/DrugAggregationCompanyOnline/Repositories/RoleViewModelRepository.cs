﻿using DrugAggregationCompanyOnline.Models;
using DrugAggregationCompanyOnline.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DrugAggregationCompanyOnline.Repositories
{
    public class RoleViewModelRepository : IRepository<RoleViewModel>,IEditRepository<RoleViewModel>,IDeleteRepository<Role>
    {
        private ApplicationDbContext db = new ApplicationDbContext();
        public void Add(RoleViewModel entity)
        {
            var _role = new Role()
            {
                ID = Guid.NewGuid(),
                Name = entity.Name
            };
            db.Roles.Add(_role);
            db.SaveChanges();
        }

        public void Delete(Guid? id)
        {
            var role = db.Roles.Find(id);
            db.Roles.Remove(role);
            db.SaveChanges();
        }

        public void Edit(Guid id , RoleViewModel entity)
        {
            var role = db.Roles.Find(id);
            role.Name = entity.Name;
            db.SaveChanges();
        }

        public void Edit(Guid id, RoleViewModel entity, string serverPath)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Role> GetRoles()
        {
            var roles = db.Roles.ToList();
            return roles;
        }
    }
}