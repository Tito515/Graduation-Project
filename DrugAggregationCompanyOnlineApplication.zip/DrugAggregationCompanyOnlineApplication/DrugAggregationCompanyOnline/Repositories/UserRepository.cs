﻿using DrugAggregationCompanyOnline.Models;
using DrugAggregationCompanyOnline.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DrugAggregationCompanyOnline.Repositories
{
    public class UserRepository : IAddReposetory<UserViewModel>
    {
        private readonly ApplicationDbContext _context = new ApplicationDbContext();
        private string folderpath;
        public UserRepository()
        {
            folderpath = "/Image/Licenses/";
        }
        public void Add(UserViewModel _user, string serverpath)//This method belong to the UserRepository class
        {
            var user = new User()
            {
                ID = _user.ID,
                Name = _user.UserName,
                UserName = _user.UserName,
                Email = _user.Email,
                Password = _user.Password,
                Address = _user.Address,
                Licenses = _user.UploadImage(_user, serverpath, folderpath),
                PhoneNo = _user.PhoneNo,
                RoleID = SetRoleToUser(_user, "Customer")

            };

            _context.User.Add(user);
            _context.SaveChanges();
        }

        public Guid SetRoleToUser(UserViewModel _user, string _roleName)
        {
            var role_name = _context.Roles.FirstOrDefault(r => r.Name == _roleName);
            return _user._Role = role_name.ID;

        }


        public IEnumerable<User> GetAllUsers()
        {
            return _context.User.ToList();
        }

       
    }
}