﻿using DrugAggregationCompanyOnline.Models;
using DrugAggregationCompanyOnline.ViewModels;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace DrugAggregationCompanyOnline.Repositories
{
    public class ItemRepository : IAddReposetory<ItemViewModel>, IDeleteRepository<Item>,IEditRepository<ItemViewModel>
    {
        private readonly ApplicationDbContext _context = new ApplicationDbContext();
        private string folderpath;
        public ItemRepository()
        {
            folderpath = "/Image/Item_Photo/";
        }
        public void Add(ItemViewModel _ivm ,string serverPath)
        {
            var item = new Item()
            {
                ID = Guid.NewGuid(),
                Name = _ivm.Name,
                Company = _ivm.Company,
                Price = _ivm.Price,
                Photo = _ivm.UploadImage(_ivm, serverPath ,folderpath),
                CategoryID = _ivm.CategoryID
            };
            _context.Items.Add(item);
            _context.SaveChanges();
        }

        public void Delete(Guid? id)
        {
            var item = _context.Items.Find(id);
            _context.Items.Remove(item);
            _context.SaveChanges();
        }

        //public void Edit(Guid id,ItemViewModel entity, string serverPath)
        //{
        //    var item = _context.Items.Find(id);
            
        //    item.Name = entity.Name;
        //    item.Price = entity.Price;
        //    item.Company = entity.Company;
        //    item.CategoryID = entity.CategoryID;
        //    item.Photo = entity.UploadImage(entity, serverPath);
        //    _context.Entry(item).State =EntityState.Modified;
        //    _context.SaveChanges();


        //}

        public void Edit(Guid id, ItemViewModel entity, string serverPath)
        {
            var item = _context.Items.Find(id);

            item.Name = entity.Name;
            item.Price = entity.Price;
            item.Company = entity.Company;
            item.CategoryID = entity.CategoryID;
            item.Photo = entity.UploadImage(entity, serverPath,folderpath);
            _context.Entry(item).State = EntityState.Modified;
            _context.SaveChanges();
        }

        public void Edit(Guid id, ItemViewModel entity)
        {
            throw new NotImplementedException();
        }
    }
}