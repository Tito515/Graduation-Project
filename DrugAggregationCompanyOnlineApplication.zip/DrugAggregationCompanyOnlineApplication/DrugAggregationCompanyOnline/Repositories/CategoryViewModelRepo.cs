﻿using DrugAggregationCompanyOnline.Models;
using DrugAggregationCompanyOnline.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DrugAggregationCompanyOnline.Repositories
{
    public class CategoryViewModelRepo : IRepository<CategoryViewModel>, IDeleteRepository<Category>,IEditRepository<CategoryViewModel>
    {
        private readonly ApplicationDbContext _context = new ApplicationDbContext();

        public void Add(CategoryViewModel entity)
        {

            var category = new Category()
            {
                ID = Guid.NewGuid(),
                Name = entity.Name

            };
            _context.Category.Add(category);
            _context.SaveChanges();

        }

        public void Delete(Guid? id)
        {
            var category = _context.Category.Find(id);
            _context.Category.Remove(category);
            _context.SaveChanges();
        }

        public void Edit(Guid id, CategoryViewModel entity)
        {
            var cat = _context.Category.Find(id);
            cat.Name = entity.Name;
            _context.SaveChanges();
        }

        public void Edit(Guid id, CategoryViewModel entity, string serverPath)
        {
            throw new NotImplementedException();
        }
    }
}